#!/bin/bash
echo "Hello, this script is running from daemon at $(date)" >> ~/daemon_log.txt
