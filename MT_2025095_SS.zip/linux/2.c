/*
============================================================================
Name : 2.c
Author : Prins Mishra
Description :2. Write a simple program to execute in an infinite loop at the background. Go to /proc directory and
identify all the process related information in the corresponding proc directory.
Date: 28th Aug, 2025.
============================================================================
*/






#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    while (1) {
//        printf("Process is running...\n");
        sleep(5);
    }
    return 0;
}
//[1] 5287

